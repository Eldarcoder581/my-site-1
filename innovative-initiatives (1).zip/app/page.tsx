import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"

export default function HomePage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative w-full h-[500px] md:h-[600px] lg:h-[700px] bg-primary-blue text-white flex items-center justify-center">
        <Image
          src="/placeholder.svg"
          alt="Hero Background"
          layout="fill"
          objectFit="cover"
          className="absolute inset-0 opacity-30"
        />
        <div className="relative z-10 text-center px-4 md:px-6 max-w-4xl space-y-4">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight">
            Yeniliyə açılan qapı: Sosial və Elmi Təşəbbüslər
          </h1>
          <p className="text-lg md:text-xl">
            Maarifləndirmə, yaradıcı düşüncə və milli dəyərlərin inkişafı üçün platforma
          </p>
          <Button className="bg-white text-primary-blue hover:bg-gray-100 px-8 py-3 rounded-full text-lg font-medium">
            Lay heylara basın
          </Button>
        </div>
      </section>

      {/* Projects Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50 dark:bg-gray-900">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Layihələr</h2>
              <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                Bəzi əsas layihələrimizə nəzər salın.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-start gap-6 py-12 lg:grid-cols-2 xl:grid-cols-2">
            <Card className="flex flex-col md:flex-row items-center gap-4 p-4">
              <Image
                src="/placeholder.svg"
                width={120}
                height={120}
                alt="Project Image"
                className="rounded-lg object-cover aspect-square"
              />
              <div className="grid gap-1">
                <h3 className="text-xl font-bold">Dayər Muzeyi</h3>
                <p className="text-gray-500 dark:text-gray-400">Muzeyin dəyərtəriyə yerinə mədəni tro özü</p>
              </div>
            </Card>
            <Card className="flex flex-col md:flex-row items-center gap-4 p-4">
              <Image
                src="/placeholder.svg"
                width={120}
                height={120}
                alt="Project Image"
                className="rounded-lg object-cover aspect-square"
              />
              <div className="grid gap-1">
                <h3 className="text-xl font-bold">Maarifləndirici Xatkəs</h3>
                <p className="text-gray-500 dark:text-gray-400">Maarifləndifən alatin imkanien</p>
              </div>
            </Card>
            <Card className="flex flex-col md:flex-row items-center gap-4 p-4">
              <Image
                src="/placeholder.svg"
                width={120}
                height={120}
                alt="Project Image"
                className="rounded-lg object-cover aspect-square"
              />
              <div className="grid gap-1">
                <h3 className="text-xl font-bold">Bayrağa,Sadaqat Andı</h3>
                <p className="text-gray-500 dark:text-gray-400">Əziz xalqını təhsilinə</p>
              </div>
            </Card>
            <Card className="flex flex-col md:flex-row items-center gap-4 p-4">
              <Image
                src="/placeholder.svg"
                width={120}
                height={120}
                alt="Project Image"
                className="rounded-lg object-cover aspect-square"
              />
              <div className="grid gap-1">
                <h3 className="text-xl font-bold">Tədris Kursları və Sosial Aksiyalar</h3>
                <p className="text-gray-500 dark:text-gray-400">Təhsil aksiyaları</p>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* About and Contact Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-white dark:bg-gray-950">
        <div className="container grid items-center gap-6 px-4 md:px-6 lg:grid-cols-2 lg:gap-10">
          <div className="space-y-4">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Haqqında</h2>
            <div className="flex items-center gap-4">
              <Image
                src="/placeholder.svg"
                width={120}
                height={120}
                alt="Şəraf Əhmədov"
                className="rounded-full object-cover aspect-square"
              />
              <div>
                <h3 className="text-xl font-bold">Şəraf Əhmədov</h3>
                <p className="text-gray-500 dark:text-gray-400">Hüquqşünas və direktor</p>
              </div>
            </div>
            <p className="max-w-[600px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Şəraf Əhmədov, innovativ təşəbbüslərin inkişafına sadiq olan təcrübəli hüquqşünas və direktordur. Onun
              rəhbərliyi altında təşkilatımız bir çox uğurlu layihələr həyata keçirmişdir.
            </p>
          </div>
          <div className="space-y-4">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Əlaqə</h2>
            <form className="grid gap-4">
              <Input type="text" placeholder="Ad" className="w-full" />
              <Input type="email" placeholder="Email" className="w-full" />
              <Textarea placeholder="Mesaj" className="w-full min-h-[100px]" />
              <Button type="submit" className="w-full bg-primary-blue text-white hover:bg-primary-blue/90">
                Göndər
              </Button>
            </form>
          </div>
        </div>
      </section>
    </div>
  )
}
