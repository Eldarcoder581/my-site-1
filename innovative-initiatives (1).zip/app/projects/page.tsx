import Image from "next/image"
import { Card } from "@/components/ui/card"

export default function ProjectsPage() {
  return (
    <div className="flex flex-col items-center py-12 md:py-24 lg:py-32 px-4 md:px-6">
      <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter mb-12 text-center">Layihələr</h1>

      <div className="grid gap-6 w-full max-w-4xl">
        <Card className="flex flex-col md:flex-row items-center gap-6 p-6">
          <Image
            src="/placeholder.svg"
            width={150}
            height={150}
            alt="Project Image"
            className="rounded-lg object-cover aspect-square flex-shrink-0"
          />
          <div className="grid gap-2">
            <h3 className="text-2xl font-bold">Dayər Muzeyi</h3>
            <p className="text-gray-500 dark:text-gray-400">Muzeyimizin dilbərgiyşəmn kültürhazinasıdır</p>
          </div>
        </Card>
        <Card className="flex flex-col md:flex-row items-center gap-6 p-6">
          <Image
            src="/placeholder.svg"
            width={150}
            height={150}
            alt="Project Image"
            className="rounded-lg object-cover aspect-square flex-shrink-0"
          />
          <div className="grid gap-2">
            <h3 className="text-2xl font-bold">Maarifləndirici Xatkəs</h3>
            <p className="text-gray-500 dark:text-gray-400">Elukasivenin ikal nialqilak mümkəndənatla</p>
          </div>
        </Card>
        <Card className="flex flex-col md:flex-row items-center gap-6 p-6">
          <Image
            src="/placeholder.svg"
            width={150}
            height={150}
            alt="Project Image"
            className="rounded-lg object-cover aspect-square flex-shrink-0"
          />
          <div className="grid gap-2">
            <h3 className="text-2xl font-bold">Bayrağa Sadaqat Andı</h3>
            <p className="text-gray-500 dark:text-gray-400">Azadayan lış ilaqan ...</p>
          </div>
        </Card>
        <Card className="flex flex-col md:flex-row items-center gap-6 p-6">
          <Image
            src="/placeholder.svg"
            width={150}
            height={150}
            alt="Project Image"
            className="rounded-lg object-cover aspect-square flex-shrink-0"
          />
          <div className="grid gap-2">
            <h3 className="text-2xl font-bold">Tədris Kursları və Sosial Aksiyalar</h3>
            <p className="text-gray-500 dark:text-gray-400">Edükasiyayl kurslar</p>
          </div>
        </Card>
      </div>
    </div>
  )
}
