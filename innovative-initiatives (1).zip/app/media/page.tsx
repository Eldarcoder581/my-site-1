import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card } from "@/components/ui/card"

export default function MediaPage() {
  return (
    <div className="flex flex-col items-center py-12 md:py-24 lg:py-32 px-4 md:px-6">
      <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter mb-8 text-center">Media Mərkəzi</h1>

      <Tabs defaultValue="photo" className="w-full max-w-4xl mb-8">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="photo">Foto Qalereya</TabsTrigger>
          <TabsTrigger value="video">Video Arxiv</TabsTrigger>
          <TabsTrigger value="news">Mətbuat Xəbərləri</TabsTrigger>
        </TabsList>
        <TabsContent value="photo">
          <div className="flex flex-wrap justify-center gap-2 mb-8 mt-4">
            <Button variant="outline" className="rounded-full">
              Bütün
            </Button>
            <Button variant="outline" className="rounded-full">
              Tədbirlər
            </Button>
            <Button variant="outline" className="rounded-full">
              Məhsullar
            </Button>
            <Button variant="outline" className="rounded-full">
              Layihələr
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
            <Card className="overflow-hidden rounded-lg shadow-lg">
              <Image
                src="/placeholder.svg"
                width={400}
                height={250}
                alt="Media Image"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold">Yeni layihənin təqdimatı</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Tədbirlər</p>
              </div>
            </Card>
            <Card className="overflow-hidden rounded-lg shadow-lg">
              <Image
                src="/placeholder.svg"
                width={400}
                height={250}
                alt="Media Image"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold">Brend məhsullar</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Məhsullar</p>
              </div>
            </Card>
            <Card className="overflow-hidden rounded-lg shadow-lg">
              <Image
                src="/placeholder.svg"
                width={400}
                height={250}
                alt="Media Image"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold">Könüllülük haqqında mühazirə</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Tədbirlər</p>
              </div>
            </Card>
            <Card className="overflow-hidden rounded-lg shadow-lg">
              <Image
                src="/placeholder.svg"
                width={400}
                height={250}
                alt="Media Image"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold">Muzey sərgisi</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Tədbirlər</p>
              </div>
            </Card>
            <Card className="overflow-hidden rounded-lg shadow-lg">
              <Image
                src="/placeholder.svg"
                width={400}
                height={250}
                alt="Media Image"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold">Təlim üçün alətlər dəsti</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Layihələr</p>
              </div>
            </Card>
            <Card className="overflow-hidden rounded-lg shadow-lg">
              <Image
                src="/placeholder.svg"
                width={400}
                height={250}
                alt="Media Image"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold">Tədbir layihəsi</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Tədbirlər</p>
              </div>
            </Card>
            <Card className="overflow-hidden rounded-lg shadow-lg">
              <Image
                src="/placeholder.svg"
                width={400}
                height={250}
                alt="Media Image"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold">Muzey sərgisi</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Tədbirlər</p>
              </div>
            </Card>
            <Card className="overflow-hidden rounded-lg shadow-lg">
              <Image
                src="/placeholder.svg"
                width={400}
                height={250}
                alt="Media Image"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold">Təqdimat materialları</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Məhsullar</p>
              </div>
            </Card>
            <Card className="overflow-hidden rounded-lg shadow-lg">
              <Image
                src="/placeholder.svg"
                width={400}
                height={250}
                alt="Media Image"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold">Tədbir çəkilişi</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Tədbirlər</p>
              </div>
            </Card>
          </div>
        </TabsContent>
        {/* Add TabsContent for Video Arxiv and Mətbuat Xəbərləri if needed */}
      </Tabs>
    </div>
  )
}
