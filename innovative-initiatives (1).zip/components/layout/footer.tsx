import Link from "next/link"
import { Facebook, Instagram } from "lucide-react"

export default function Footer() {
  return (
    <footer className="flex flex-col sm:flex-row items-center justify-between h-20 px-4 md:px-6 bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400">
      <p className="text-sm">&copy; 2023 INNOVATIV TƏŞƏBBÜSLƏR. All rights reserved.</p>
      <nav className="flex items-center gap-4 mt-4 sm:mt-0">
        <Link href="#" className="hover:underline underline-offset-4 text-sm" prefetch={false}>
          Əlaqə
        </Link>
        <div className="flex gap-2">
          <Link
            href="#"
            className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50"
            prefetch={false}
          >
            <Facebook className="h-5 w-5" />
            <span className="sr-only">Facebook</span>
          </Link>
          <Link
            href="#"
            className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50"
            prefetch={false}
          >
            <Instagram className="h-5 w-5" />
            <span className="sr-only">Instagram</span>
          </Link>
        </div>
      </nav>
    </footer>
  )
}
