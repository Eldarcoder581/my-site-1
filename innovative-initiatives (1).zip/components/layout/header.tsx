import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

export default function Header() {
  return (
    <header className="flex items-center justify-between h-16 px-4 md:px-6 bg-primary-blue text-white">
      <Link href="#" className="flex items-center gap-2 text-lg font-bold" prefetch={false}>
        <span className="sr-only">Home</span>
        INNOVATIV TƏŞƏBBÜSLƏR
      </Link>
      <nav className="hidden md:flex items-center gap-6">
        <Link href="/" className="hover:underline underline-offset-4" prefetch={false}>
          Ana Səhifə
        </Link>
        <Link href="#" className="hover:underline underline-offset-4" prefetch={false}>
          Haqqında
        </Link>
        <Link href="/projects" className="hover:underline underline-offset-4" prefetch={false}>
          Layihələr
        </Link>
        <Link href="#" className="hover:underline underline-offset-4" prefetch={false}>
          Tədbirlər
        </Link>
        <Link href="/media" className="hover:underline underline-offset-4" prefetch={false}>
          Qalereya
        </Link>
        <Link href="#" className="hover:underline underline-offset-4" prefetch={false}>
          Əlaqə
        </Link>
      </nav>
      <Button variant="ghost" size="icon" className="md:hidden text-white">
        <Search className="h-5 w-5" />
        <span className="sr-only">Search</span>
      </Button>
      <Button variant="ghost" size="icon" className="hidden md:flex text-white">
        <Search className="h-5 w-5" />
        <span className="sr-only">Search</span>
      </Button>
    </header>
  )
}
